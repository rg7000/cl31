import os
import sys
import Tkinter

def list():
    os.system("./dropbox_uploader.sh list")
    print("Enter next command")

def create():
    try:
        dir_name = raw_input("Enter directory name: ")
        os.system("./dropbox_uploader.sh mkdir "+dir_name)
    except:
        print("Unable to create the directory")
    print("Successfully created directory")
    print("Enter next command")

def delete():
    try:
        dir_name = raw_input("Enter directory name you want to delete")
        os.system("./dropbox_uploader.sh delete "+dir_name)
    except:
        print("Unable to delete directory.")
    print("Deletion successful")
    print("Enter next command")



def bye():
    print("Bye!")
    exit()

class simpleapp(Tkinter.Tk):
    def __init__(self, parent):
        Tkinter.Tk.__init__(self)
        self.parent = parent
        self.initialize()
 
    def initialize(self):
        b1 = Tkinter.Button(self, text="List", command=list)
        b1.grid(column=1, row=2)

        b2 = Tkinter.Button(self, text = "Create", command=create)
        b2.grid(column=2, row=2)
 
        b3 = Tkinter.Button(self, text="Exit", command=bye)
        b3.grid(column=2, row=4)

        b4 = Tkinter.Button(self, text="Delete", command=delete)
        b4.grid(column=1, row=4)
app = simpleapp(None)
app.title("Dropbox")
app.mainloop()
