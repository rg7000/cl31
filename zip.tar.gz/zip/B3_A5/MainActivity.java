package com.example.shivani.rishika_pract;

import android.content.Context;
import android.content.res.AssetManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    String str = "" ;
    String str1 = "";
    public double answer =0;
    public double history = 0 ;
    TextView result;
    TextView info;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        result = (TextView)findViewById(R.id.result);
        info = (TextView)findViewById(R.id.info);
        answer = 0;
    }

    String[] arr = {"*", "/","+","-"};
    ArrayList<String> op = new ArrayList<>(Arrays.asList(arr));
    ArrayList<String> A = new ArrayList<>();
    ArrayList<String> B = new ArrayList<>();

    public ArrayList<String > cloneList(ArrayList<String> A)
    {
        ArrayList<String> clone = new ArrayList<>(A.size());
        for(String item: A)
        {
                clone.add(item);
        }
        return clone;
    }

    public void click1(View v){

        Button btn = (Button) v;
        str = btn.getText().toString();

        if(op.contains(str))
        {
            if(A.size()== 0)
            {
                str1 = str;
            }
            else
            {
                A.add(str);
                str1 = "";
            }
        }
        else
        {
            int len = A.size();
            if(len > 2)
            {
                if(op.contains(A.get(len - 2)) && op.contains(A.get(len - 1)))
                {
                    str1 = A.get(len - 1);
                    str1 = str1 + str;
                    A.remove(len-1);
                    A.add(str1);
                }
                else {
                    str1 = str1 + str;
                    if (len > 0 && !op.contains(A.get(len - 1)))
                        A.remove(len - 1);
                    A.add(str1);
                }
            }

            else {
                str1 = str1 + str;
                if (len > 0 && !op.contains(A.get(len - 1)))
                    A.remove(len - 1);
                A.add(str1);
            }
        }

        if(A.size() == 1){

            answer = Double.parseDouble(A.get(0));
        }

        info.setText(info.getText().toString() + str);
        B.clear();
        B = cloneList(A);

        if(B.size()>2 && B.size()%2!=0 && !op.contains(B.get(B.size() - 1)))
        {
            click(v);
        }
    }

    public void click(View v)
    {
        int len = B.size();
        while(len > 1)
        {
        if (len > 3)
        {
            if(B.get(3).equals("*") || B.get(3).equals("/") ) {
                if (B.get(3).equals("*")) {
                    answer = Double.parseDouble(B.get(2)) * Double.parseDouble(B.get(4));
                } else if (B.get(3).equals("/")) {
                    answer = Double.parseDouble(B.get(2)) / Double.parseDouble(B.get(4));
                }

                B.remove(2);
                B.remove(2);
                B.remove(2);
                B.add(2, Double.toString(answer));
                len = B.size();
            }
            else{
                if (B.get(1).equals("*"))
                answer = Double.parseDouble(B.get(0)) * Double.parseDouble(B.get(2));
            else if (B.get(1).equals("/"))
                answer = Double.parseDouble(B.get(0)) / Double.parseDouble(B.get(2));
            else if (B.get(1).equals("+"))
                answer = Double.parseDouble(B.get(0)) + Double.parseDouble(B.get(2));
            else if (B.get(1).equals("-"))
                answer = Double.parseDouble(B.get(0)) - Double.parseDouble(B.get(2));
            B.remove(0);
            B.remove(0);
            B.remove(0);
            B.add(0,Double.toString(answer));
            len = B.size();
            }
        }
        else{
            if (B.get(1).equals("*"))
                answer = Double.parseDouble(B.get(0)) * Double.parseDouble(B.get(2));
            else if (B.get(1).equals("/"))
                answer = Double.parseDouble(B.get(0)) / Double.parseDouble(B.get(2));
            else if (B.get(1).equals("+"))
                answer = Double.parseDouble(B.get(0)) + Double.parseDouble(B.get(2));
            else if (B.get(1).equals("-"))
                answer = Double.parseDouble(B.get(0)) - Double.parseDouble(B.get(2));
            B.remove(0);
            B.remove(0);
            B.remove(0);
            B.add(0,Double.toString(answer));
            len = B.size();
        }


        }//while ends

        result.setText(String.valueOf(answer));
    }

    public void clear(View v )
    {
        result.setText(null);
        info.setText(null);
        A.clear();
        str = "";
        str1 = "";
        answer = 0;
    }

    public void store(View v)
    {
        history = answer;
        result.setText(null);
        info.setText(null);
    }

    public void recall(View v)
    {
        result.setText(null);
        info.setText(null);
        info.setText(String.valueOf(history));
        A.clear();
        A.add(String.valueOf(history));
        answer = 0;
    }

    public void file_read(View v)
    {
        try{
            Context context = this;
            AssetManager am = context.getAssets();
            InputStream is = am.open("file.txt");
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String s = br.readLine();
            for (int i = 0; i < s.length();i++)
            {
                str = Character.toString(s.charAt(i));
                if(op.contains(str))
                {
                    if(A.size()== 0)
                    {
                        str1 = str;
                    }
                    else
                    {
                        A.add(str);
                        str1 = "";
                    }
                }
                else
                {
                    int len = A.size();
                    if(len > 2)
                    {
                        if(op.contains(A.get(len - 2)) && op.contains(A.get(len - 1)))
                        {
                            str1 = A.get(len - 1);
                            str1 = str1 + str;
                            A.remove(len-1);
                            A.add(str1);
                        }
                        else {
                            str1 = str1 + str;
                            if (len > 0 && !op.contains(A.get(len - 1)))
                                A.remove(len - 1);
                            A.add(str1);
                        }
                    }

                    else {
                        str1 = str1 + str;
                        if (len > 0 && !op.contains(A.get(len - 1)))
                            A.remove(len - 1);
                        A.add(str1);
                    }
                }

                if(A.size() == 1){

                    answer = Double.parseDouble(A.get(0));
                }

                info.setText(info.getText().toString() + str);
                B.clear();
                B = cloneList(A);

                if(B.size()>2 && B.size()%2!=0 && !op.contains(B.get(B.size() - 1)))
                {
                    click(v);
                }

            }
        }catch  (Exception e){}


    }

}



