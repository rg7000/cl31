from flask import Flask, request, render_template
app = Flask(__name__)
text1 = []
text2 = []
text3 = []
with open("text1.txt", 'r') as f:
    for line in f:
        text1.append(line.strip())
with open("text2.txt", 'r') as f:
    for line in f:
        text2.append(line.strip())
with open("text3.txt", 'r') as f:
    for line in f:
        text3.append(line.strip())
@app.route('/')
def hello():
    return render_template("index.html")
@app.route('/check', methods=['GET', 'POST'])
def check():
    if request.method == 'POST':
        data = request.form["text"]
        lines = data.split("\n")
        textdatabase = [text1, text2, text3]
        matches = 0
        rendertext = "<h3 align=center>Given Text:<br>"
        for line in lines:
            rendertext = rendertext + " " + line
        rendertext = rendertext + "</h3>"
        for file in textdatabase:
            for line in lines:
                if line.strip() in file:
                    matches += 1
        perc = (float(matches)/len(lines))*100
        response = "<h3 align=center>Plagarism score:<b>"+str(perc)+"%</b></h3>"
        return rendertext +"<br>"+response
    else:
        return render_template("prag.html")
    
if __name__ == ("__main__"):
    app.run(host='localhost', debug=True, port=5000)
