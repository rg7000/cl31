import json
import unittest

class MyTest(unittest.TestCase):
    def test_positive(self):
        print("=====POSITIVE TESTING======")
        self.assertEqual(run("input_pos.json"), True)
    def test_negative(self):
        print("=====NEGATIVE TESTING======")
        self.assertEqual(run("input_neg.json"), False)
def printboard(board):
    for i in range(8):
        for j in range(8):
            if(board[i][j] == 1):
                print("Q"),
            else:
                print("-"),
        print("")

def isattack(board, row, col):
    for i in range(row):
        if(board[i][col] == 1):
            return True
    i = row - 1
    j = col - 1
    while i>=0 and j >=0:
        if(board[i][j] == 1):
            return True
        i -= 1
        j -= 1

    i = row - 1
    j = col + 1
    while (i >= 0 and j <= 7):
        if(board[i][j] == 1):
            return True
        i -= 1
        j += 1
    return False    

def solve(board, row):
    i = 0
    while i<8:
        if(not isattack(board, row, i)):
            board[row][i] = 1
            if(row == 7):
                return True
            else:
                if(solve(board, row+1)):
                    return True
                else:
                    board[row][i] = 0
        i+=1
    if(i == 8):
        return False

def run(file_name):
    with open(file_name) as f:
        data = json.load(f)
    if(data["start"] > 7 or data["start"] < 0):
        print("Invalid Json INPUT")
        return False
    board = [[0 for i in range(8)] for i in range(8)]
    board[0][data["start"]] = 1
    if(solve(board, 1)):
        print("8 queens solved")
        printboard(board)
        return True
    else:
        print("8 queens not solved")
        return False

#run("input.json")
print("-------------UNIT TESTING----------------")
unittest.main()
