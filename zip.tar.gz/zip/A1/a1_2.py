import unittest
class Binary_Search():
    def bin_search(self, arr, key, size):
        mid = -1
        flag = 0
        low = 0
        high = size - 1
        while(low <= high):
            mid = int((low+high)/2)
            if(arr[mid] == key):
                print("Element "+str(key)+" found at pos "+str(mid+1)+" of sorted array.")
                flag = 1
                return (mid+1)
            elif(arr[mid] > key):
                high = mid - 1
            elif(arr[mid] < key):
                low = mid + 1
        if(not flag):
            print("Element "+str(key)+" not found in array.")
            return -1
class MyTestCase(unittest.TestCase):
    def test_positive(self):
        obj = Binary_Search()
        print("Positive Test Case: ")
        if(self.assertEqual(obj.bin_search([10, 20, 30, 40, 50], 40, 5), 4)):
            print("Positive Test Case : SUCCESS!!")
        else:
            print("Positive Test Case: Error in code")
    def test_negative(self):
        obj = Binary_Search()
        print("Negative Test Case")
        if(self.assertEqual(obj.bin_search([10, 20, 30, 40, 50], 100,5), -1)):
            print("Negative Test Case: Result as expected")
        else:
            print("Negative Test Case: Error in code")
if __name__ == "__main__":
    n = input("Enter number of elements: ")
    a = []
    print("\nEnter the elements: ")
    for i in range(n):
        a.append(input())
    a.sort()
    print("\nSorted array is: ")
    for elem in a:
        print(elem),
#    while(True):
    key = input("\nEnter element to be searched: ")
    obj = Binary_Search()
    obj.bin_search(a, key, n)
    print("=============TESTING==============")
    unittest.main()
