import threading
import xml.etree.ElementTree as ET

def getdata(f):
    data = ET.parse(f)
    root = data.getroot()
    a = []
    for child in root:
        a.append(int(child.text))
    print "Array list from file: ",a
    return a

class sort():
    def partition(self, a, low, high):
        pivot = a[high]
        i = low -1 
        for j in range(low, high):
            if(a[j] <= pivot):
                i += 1
                a[i], a[j] = a[j], a[i]
        a[i+1], a[high] = a[high], a[i+1]
        return (i+1), pivot


    def quicksort(self, arr, low, high):
        if(low <= high):
            pos, pivot = self.partition(arr, low, high)
            print "Thread "+str(threading.current_thread().getName())+"found the position of "+str(pivot)+ " at "+str(pos)
            t1 = threading.Thread(target = self.quicksort, args = (arr, low, pos-1))
            t1.start()
            t2 = threading.Thread(target = self.quicksort, args = (arr, pos  + 1, high))
            t2.start()
            t1.join()
            t2.join()

if __name__ == "__main__":
    arr = getdata("a3.xml")
    obj = sort()
    obj.quicksort(arr, 0, len(arr) - 1)
    print "Sorted array is ",arr
