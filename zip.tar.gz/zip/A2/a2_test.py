import unittest
from a2_1 import *
class MyTest(unittest.TestCase):
    def test_fetch(self):
        try:
            a = getdata("a3.xml")
            if(a == None):
                self.fail("Data not fetched")
        except:
            self.fail("File doesn't exist")

    def test_array(self):
        self.assertEqual((getdata("a3.xml")), [34, 14, 44, 4, 74])
unittest.main()
